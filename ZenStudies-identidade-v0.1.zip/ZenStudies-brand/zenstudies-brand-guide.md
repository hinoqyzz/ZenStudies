# ZenStudies — identidade visual v0.1

## Resumo executivo

ZenStudies é um ambiente pessoal para estudar, anotar e revisar todos os dias. A identidade evita os clichês de educação e bem-estar — livro aberto, cérebro, lâmpada, lótus e pose de meditação — e se organiza ao redor de uma ideia proprietária: **Ciclo Calmo**.

O símbolo combina dois ciclos quadrados arredondados e um núcleo central. Os ciclos representam captura e revisão; a sobreposição representa conexão entre conteúdos; o núcleo representa o foco do dia. A construção é modular, funciona em tamanhos pequenos e pode virar padrão, motion e componente de interface.

> Status: sistema conceitual pronto para prototipagem. Antes de lançamento comercial, converter a tipografia do logotipo em curvas, testar tamanhos mínimos nos dispositivos reais, medir todos os contrastes de estado e fazer busca formal de marca.

## Premissas usadas

- Produto pessoal, inicialmente de marca única.
- Uso recorrente em celular e desktop.
- Funções centrais: estudos, anotações, organização e revisões.
- Experiência desejada: calma sem passividade; tecnologia sem frieza.
- Público-base: estudantes e autodidatas que querem continuidade e menos sensação de desorganização.

## Diagnóstico de categoria

A categoria costuma recorrer a quatro atalhos visuais: azul genérico de SaaS, ilustrações escolares, mascotes infantis e símbolos literais de livro/cérebro. O território de ZenStudies é diferente: **clareza modular + calma ativa**. A marca deve parecer um instrumento pessoal bem projetado, não uma escola digital nem um aplicativo de meditação.

## Posicionamento

**Para estudantes e autodidatas, ZenStudies é um espaço pessoal de estudo que reúne anotações e revisões em um ritmo diário calmo, por meio de uma organização visual simples e contínua.**

### Promessa

Voltar ao que importa, sem perder o fio.

### Pilares

1. **Clareza calma** — cada tela mostra a próxima ação sem ruído.
2. **Continuidade visível** — o sistema evidencia progresso e retomada, não culpa.
3. **Simplicidade útil** — poucos elementos, cada um com função real.
4. **Controle pessoal** — o usuário organiza seu próprio método.

### Personalidade

Precisa, acolhedora, contemporânea e discreta. Nunca infantil, mística, competitiva ou excessivamente motivacional.

## Rotas criativas consideradas

| Rota | Ideia | Força | Risco | Decisão |
|---|---|---|---|---|
| **Ciclo Calmo** | módulos conectados e espaço central | equilibra estudo, revisão e serenidade | exige construção consistente | **recomendada** |
| Dobra Lúcida | uma folha dobrada forma um “Z” | forte relação com notas | pode parecer editor de documentos | alternativa |
| Ritmo Modular | pontos e barras formam uma cadência | boa para dados e progresso | pode ficar técnico demais | alternativa |

## Sistema do logotipo

### Símbolo

- Dois módulos de 68 unidades, cantos de 23 unidades e traço de 12 unidades.
- Deslocamento diagonal de 32 unidades entre os ciclos.
- Núcleo de 38 unidades, com canto de 12 unidades.
- As sobreposições não devem ser rearranjadas: elas criam a assinatura visual.

### Assinaturas

- **Horizontal:** símbolo à esquerda + “ZenStudies”. É a versão principal para cabeçalhos e telas de entrada.
- **Símbolo isolado:** app icon, favicon, avatar e controles compactos.
- **Monocromática:** todo o símbolo em `#101C1A` sobre fundo claro ou em `#F5F6F0` sobre fundo escuro.

### Área de proteção

Use ao redor do logo uma margem mínima igual à largura do núcleo central. Nenhum texto, borda ou imagem deve entrar nessa área.

### Tamanho mínimo provisório

- Símbolo digital: 20 px de largura, sujeito a teste em Android, iOS e Windows.
- Assinatura horizontal: 112 px de largura, sujeito a teste de renderização da tipografia.
- Abaixo disso, usar apenas o símbolo simplificado e sem contorno claro do núcleo.

### Usos proibidos

- Não alterar o deslocamento dos dois ciclos.
- Não aplicar sombra, contorno extra ou gradiente ao logo.
- Não usar cada segmento com uma cor diferente.
- Não colocar sobre fotografia sem uma área de contraste controlada.
- Não substituir o núcleo por livro, cérebro, check ou letra.
- Não condensar, inclinar ou esticar a assinatura.

## Paleta

| Papel | Nome | HEX | Uso |
|---|---|---:|---|
| Fundo | Papel | `#F5F6F0` | telas claras, documentos, respiro |
| Texto/fundo escuro | Tinta | `#101C1A` | títulos, corpo, app icon, modo escuro |
| Ação primária | Foco Violeta | `#6558E8` | CTA, seleção, progresso ativo |
| Acento | Menta Viva | `#73D8B2` | núcleo, feedback positivo, destaques limitados |
| Texto secundário | Ardósia | `#52625E` | metadados e legendas |
| Divisor | Névoa | `#D4DDD8` | linhas, campos e superfícies discretas |

Regras: violeta conduz ações; menta indica conexão, retorno ou conclusão. A menta não deve ser usada como texto pequeno sobre branco.

Contrastes medidos nesta proposta:

- Tinta sobre Papel: **16,06:1**.
- Ardósia sobre Papel: **5,91:1**.
- Branco sobre Foco Violeta: **5,10:1**.
- Tinta sobre Menta Viva: **10,14:1**.
- Papel sobre Tinta: **16,06:1**.

Esses pares atendem WCAG AA para texto normal. Ainda é necessário medir estados derivados, transparências, componentes desabilitados e qualquer nova combinação antes de produção.

## Tipografia

- **Manrope 700/600:** display, títulos, navegação e números de progresso.
- **Inter 500/400:** corpo, notas, campos, legendas e microcopy.
- Alternativa de sistema: `Segoe UI` no Windows e `SF Pro` nos sistemas Apple.

Diretrizes:

- Títulos com espaçamento compacto, sem caixa alta prolongada.
- Corpo com 16 px e entrelinha de 1,5 como ponto de partida.
- Metadados nunca abaixo de 12 px em interfaces comuns.
- Evitar peso 300 em telas pequenas.

## Composição e linguagem gráfica

- Grid-base de 8 px; microajustes em 4 px.
- Cartões com cantos de 14 a 22 px, nunca totalmente “pill” em grandes superfícies.
- Uma única região dominante por tela.
- Blocos podem se sobrepor em ilustrações, mas não em conteúdo funcional.
- O padrão usa ciclos abertos, módulos deslocados e um núcleo; densidade máxima de 20% do plano.
- Fotografia, se usada, deve mostrar estudo real e cotidiano, com luz natural e sem encenação escolar óbvia.

## Iconografia

- Traço uniforme de 1,75 px em uma grade de 24 px.
- Cantos arredondados, terminais redondos e poucas diagonais.
- Ícones devem representar ações concretas: anotar, revisar, relacionar, arquivar e retomar.
- Evitar ícones ornamentais ou duplicação com rótulos claros.

## Motion

- **Entrada:** módulos convergem suavemente para o núcleo em 420 ms.
- **Conclusão de revisão:** o núcleo expande 6% e retorna em 220 ms.
- **Troca de contexto:** um ciclo desliza 8 px enquanto o outro permanece como âncora.
- Curva-padrão: `cubic-bezier(0.22, 1, 0.36, 1)`.
- Respeitar “reduzir movimento”; nenhuma ação deve depender apenas de animação.

## Voz da marca

| Atributo | Fazer | Evitar |
|---|---|---|
| Clara | “Você tem 3 revisões para hoje.” | “Maximize seu potencial acadêmico.” |
| Calma | “Continue de onde parou.” | “Não quebre sua sequência!” |
| Encorajadora | “Uma revisão curta já conta.” | “Você está atrasado.” |
| Precisa | “Salvo agora.” | “Tudo certo por aqui!” quando algo falhou |

### Vocabulário preferido

Foco, retomar, conectar, revisar, sessão, nota, progresso, hoje, depois.

### Vocabulário a evitar

Hack, dominar, esmagar metas, produtividade extrema, guru, iluminação, genialidade.

### Frases de produto

- Headline: **Seu estudo, em um ritmo que continua.**
- Subheadline: **Anote, conecte e revise sem perder o fio.**
- CTA principal: **Começar sessão**
- Retorno: **Continue de onde parou**
- Lista vazia: **Nada para revisar agora. Use este tempo para explorar suas notas.**
- Erro: **Não foi possível salvar. Sua nota continua neste dispositivo.**

## Aplicações

### Tela inicial

Um cartão dominante “Hoje” mostra a próxima sessão. Abaixo, “Retomar” e “Revisões” usam os dois ciclos como indicador de estado. Evitar dashboard cheio de gráficos.

### Editor de notas

Superfície branca, tipografia Inter, barra de ferramentas reduzida. O violeta indica seleção; a menta marca conexões entre notas, não decoração.

### Revisão

Uma pergunta por tela, progresso discreto e ações com rótulos humanos: “Ainda não”, “Quase” e “Lembrei”. Evitar vermelho como punição.

### Redes e apresentação

Usar o key art modular com bastante espaço negativo. Uma frase por peça, logo pequeno e consistente. Não transformar a marca em um mosaico multicolorido.

## Prompt principal de produção visual

```text
Use case: logo-brand / visual identity system
Asset type: presentation board and application mockups for ZenStudies
Primary request: build an original minimal identity around two offset rounded-square cycles and one calm central core, expressing notes, connections, daily review and focus without literal education or meditation symbols
Style/medium: precise vector identity, flat geometry, restrained editorial layouts, realistic product UI where applicable
Composition/framing: strong negative space, modular 8px grid, one dominant element per composition
Color palette: deep ink #101C1A, focus violet #6558E8, fresh mint #73D8B2, warm paper #F5F6F0
Text (verbatim): “ZenStudies”, “Seu estudo, em um ritmo que continua.”
Constraints: preserve the exact symbol geometry; modern and versatile; no gradients in the logo; no book, brain, lotus, meditation figure, checkmark, graduation cap, generic letter monogram, copied app marks or watermarks
```

## Plano de implantação

1. Validar a rota e a sensação geral com 3 telas reais: Hoje, Editor e Revisão.
2. Refinar a geometria óptica do símbolo em 16, 20, 24 e 48 px.
3. Converter o wordmark final em curvas e exportar SVG, PDF, PNG e ícones de plataforma.
4. Medir contraste de todos os estados interativos.
5. Fazer busca de marca no INPI e nas lojas de aplicativos antes de publicação.
6. Montar biblioteca de componentes e templates sociais.

## Checklist de aprovação

- [x] Identidade não depende de símbolos literais de estudo ou zen.
- [x] Sistema funciona em app icon, assinatura e padrão.
- [x] Paleta, tipografia, espaçamento, raio e motion estão definidos.
- [x] Voz e microcopy têm exemplos operacionais.
- [ ] Similaridade de marca e disponibilidade do nome verificadas formalmente.
- [ ] Contraste medido em todos os pares e estados.
- [ ] Tamanhos mínimos testados em dispositivos reais.
- [ ] Tipografia do wordmark convertida em curvas no arquivo final.
